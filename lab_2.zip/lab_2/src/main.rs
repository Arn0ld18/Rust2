use lab_2::part_2::Request;

fn main() {

    //// part 2
    Request::read();
    Request::to_toml();
}
